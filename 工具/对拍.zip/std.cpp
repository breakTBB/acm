#include <bits/stdc++.h>
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define dbg(x) cout << #x << ": " << x << endl;

using namespace std;

typedef unsigned long long ull;

set<ull> st;
double upper = log(pow(2.0, 64.0) - 1);
int v[110];

void init() {
    for (int i = 2; i <= 100; i++) {
        if (!v[i]) {
            for (int j = i * i; j <= 100; j += i) {
                v[j] = true;
            }
        }
    }
}

ull qpow(ull a, ull b) {
    ull ret = 1;
    while (b) {
        if (b & 1) ret = ret * a;
        a = a * a;
        b >>= 1;
    }
    return ret;
}
int main() {
	freopen("out.txt", "w", stdout);
	init();
    st.insert(1);
    for (ull i = 2; i < (1 << 16); i++) {
        double t = log(i);
        for (ull j = 4; j <= int(upper / t); j++) {
            if (v[j]) {
                st.insert((qpow(i, j)));
            }
        }
    }
    for (auto it : st) {
        cout << it << endl;
    }
}