import random

# n = random.randint(1, 10)
# print(n)
# for i in range(n):
#     print(random.randint(0, 1000000), end=' ')
#     print(random.randint(0, 1000000), end=' ')
#     print(random.randint(1, 1000000), end=' ')
#     print(random.randint(1, 1000000000))

cnt = random.randint(1, 1000)

with open(r"C:\Users\PRISM17\Desktop\acm-training\工具\对拍\in", "w") as f:
    cnt =    random.randint(1, 1000)
    print(cnt, end='\n', file=f)
    for i in range(cnt):
        print(random.randint(1, 10000000), end='\n', file=f)
