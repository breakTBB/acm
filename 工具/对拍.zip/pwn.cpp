#include <cstdio>
#include <cstring>
#include <set>
#include <vector>
#include <algorithm>
 
using namespace std;
typedef long long ll;
const int maxc = 15;
const int maxk = 105;
const int limit = 10000;
 
ll total;
int C, S, A[maxc], k[maxc];
int bestc, Y[maxc][maxk];
set<int> vis[maxc];
 
void init () {
    total = 1;
    bestc = 0;
    for (int i = 0; i < C; i++) {
        scanf("%d%d", &A[i], &k[i]);
        total *= k[i];
 
        for (int j = 0; j < k[i]; j++)
            scanf("%d", &Y[i][j]);
        sort(Y[i], Y[i] + k[i]);

    }
}
 
void solveEnum (int s) {
 
    for (int i = 0; i < C; i++) {
        if (i == s)
            continue;
 
        vis[i].clear();
        for (int j = 0; j < k[i]; j++)
            vis[i].insert(Y[i][j]);
    }
 
    for (int t = 0; S; t++) {
 
        for (int i = 0; i < k[s]; i++) {
            ll n = (ll)A[s] * t + Y[s][i];
 
            if (n == 0)
                continue;
 
            bool flag = true;
            for (int c = 0; c < C; c++) {
                if (c == s)
                    continue;
 
                if (!vis[c].count(n%A[c])) {
                    flag = false;
                    break;
                }
            }
 
            if (flag) {
                printf("%lld\n", n);
                if (--S == 0)
                    break;
            }
        }
    }
}
 
int a[maxc];
vector<int> sol;

void solveChina () {
    sol.clear();
    dfs(0);
    sort(sol.begin(), sol.end());
 
    ll M = 1;
    for (int i = 0; i < C; i++)
        M *= A[i];
 
    for (int i = 0; S; i++) {
        for (int j = 0; j < sol.size(); j++) {
            ll n = M * i + sol[j];
            if (n > 0){
                printf("%lld\n", n);
                if (--S == 0)
                    break;
            }
        }
    }
}